from pydantic import BaseModel, Field
from decimal import Decimal
from uuid import UUID

class HealthResponse(BaseModel):
    status: str

class LedgerPostRequest(BaseModel):
    idempotency_key: str = Field(min_length=16, max_length=128)
    reference: str = Field(min_length=6, max_length=100)
    currency: str = Field(pattern=r"^[A-Z]{3}$")
    description: str = Field(min_length=3, max_length=255)
    debit_account_id: UUID
    credit_account_id: UUID
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=2)

class LedgerPostResponse(BaseModel):
    journal_id: UUID
    reference: str
    status: str
