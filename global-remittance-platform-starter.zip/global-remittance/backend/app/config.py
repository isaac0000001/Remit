from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    app_name: str = "Global Remittance Platform API"
    api_v1_prefix: str = "/api/v1"
    database_url: str
    jwt_secret: str
    access_token_minutes: int = 15
    cors_origins: str = "http://localhost:3000"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
