from contextlib import asynccontextmanager
from decimal import Decimal
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, func
from app.config import settings
from app.database import Base, engine, get_db
from app.models import Account, Journal, Entry
from app.schemas import HealthResponse, LedgerPostRequest, LedgerPostResponse

@asynccontextmanager
async def lifespan(app: FastAPI):
    # For initial local bootstrap only. Production schema changes must use Alembic migrations.
    if settings.app_env == "development":
        Base.metadata.create_all(bind=engine)
    yield

app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)

@app.get("/health", response_model=HealthResponse)
def health():
    return {"status": "ok"}

@app.get(f"{settings.api_v1_prefix}/ready")
def readiness(db: Session = Depends(get_db)):
    db.execute(select(1))
    return {"status": "ready"}

@app.post(f"{settings.api_v1_prefix}/internal/ledger/post", response_model=LedgerPostResponse)
def post_ledger_entry(payload: LedgerPostRequest, db: Session = Depends(get_db)):
    # Deliberately internal-only starter endpoint. Add service authentication,
    # maker-checker authorization, account ownership checks and risk controls before exposure.
    existing = db.scalar(select(Journal).where(Journal.idempotency_key == payload.idempotency_key))
    if existing:
        return {"journal_id": existing.id, "reference": existing.reference, "status": existing.status}

    debit = db.get(Account, payload.debit_account_id)
    credit = db.get(Account, payload.credit_account_id)
    if not debit or not credit:
        raise HTTPException(status_code=404, detail="Ledger account not found")
    if debit.id == credit.id or debit.currency != payload.currency or credit.currency != payload.currency:
        raise HTTPException(status_code=400, detail="Invalid ledger accounts or currency")
    if debit.status != "open" or credit.status != "open":
        raise HTTPException(status_code=409, detail="Ledger account is not open")

    journal = Journal(
        idempotency_key=payload.idempotency_key,
        reference=payload.reference,
        currency=payload.currency,
        description=payload.description,
        status="posted",
    )
    db.add(journal)
    db.flush()
    db.add_all([
        Entry(journal_id=journal.id, account_id=debit.id, side="debit", amount=payload.amount),
        Entry(journal_id=journal.id, account_id=credit.id, side="credit", amount=payload.amount),
    ])
    db.commit()
    return {"journal_id": journal.id, "reference": journal.reference, "status": journal.status}

@app.get(f"{settings.api_v1_prefix}/internal/ledger/{'{journal_id}'}")
def get_journal(journal_id: str, db: Session = Depends(get_db)):
    journal = db.scalar(select(Journal).where(Journal.id == journal_id))
    if not journal:
        raise HTTPException(status_code=404, detail="Journal not found")
    entries = db.execute(select(Entry).where(Entry.journal_id == journal.id)).scalars().all()
    return {
        "id": str(journal.id),
        "reference": journal.reference,
        "currency": journal.currency,
        "status": journal.status,
        "entries": [{"account_id": str(e.account_id), "side": e.side, "amount": str(e.amount)} for e in entries],
    }
