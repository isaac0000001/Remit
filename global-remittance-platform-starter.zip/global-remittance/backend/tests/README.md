Add automated tests before any production financial use. Required suites include:
- ledger balancing and currency isolation
- idempotency under concurrent requests
- duplicate and out-of-order provider webhooks
- payment state transitions
- authorization and tenant isolation
- AML/risk holds and manual review
- reconciliation exceptions and reversals
- backup restoration and disaster recovery
