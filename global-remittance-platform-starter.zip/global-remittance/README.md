# Global Remittance Platform

A security-conscious monorepo starter for a global, two-way remittance platform:
- `backend/`: FastAPI API, PostgreSQL ledger foundation, authentication-ready structure.
- `web/`: Next.js customer/admin web application starter.
- `mobile/`: Expo React Native starter for Android and iOS.
- `infra/`: local Docker Compose environment.

## Important production boundary
This repository is a software foundation, not authorization to provide money-transfer, deposit-taking, custody, FX dealing, or payment services. Keep live collection, conversion, wallet funding, and payouts disabled until the relevant regulated entities, licences/permissions, safeguarding arrangements, provider contracts, AML/KYC controls, and corridor approvals are confirmed by qualified counsel and compliance professionals.

The included ledger is a minimal double-entry foundation. It is not yet a complete regulated-money platform. Before live use, add independent accounting review, transaction limits, maker-checker approvals, idempotent payment orchestration, reconciliation, sanctions screening, fraud controls, security testing, monitoring, disaster recovery, and operational runbooks.

## Quick start (local development)
1. Install Docker Desktop.
2. Copy `.env.example` to `.env` and replace all secrets.
3. Run:
   ```bash
   docker compose -f infra/docker-compose.yml up --build
   ```
4. API health: `http://localhost:8000/health`
5. API docs (development only): `http://localhost:8000/docs`
6. Web app: `http://localhost:3000`

The mobile app is a separate Expo project; see `mobile/README.md`.

## GitHub
Create an empty private repository in your GitHub account, then upload this folder or push it:
```bash
git init
git add .
git commit -m "Initial remittance platform foundation"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/global-remittance-platform.git
git push -u origin main
```
Never commit `.env`, API keys, certificates, production secrets, customer data, or payment credentials.

## Production checklist
- Use managed PostgreSQL with encryption, private networking, backups and point-in-time recovery.
- Store secrets in a managed secret store; use KMS/HSM-backed key management.
- Enforce TLS, WAF, rate limits, device/session controls and MFA.
- Use a proper OIDC identity provider and verified email/phone flows.
- Add audited KYC/AML/sanctions providers and case management.
- Use a double-entry ledger with immutable posted entries and controlled reversals.
- Add idempotency keys and provider-specific webhook signature verification.
- Add settlement/reconciliation and daily control reports.
- Add observability, alerting, incident response and tested disaster recovery.
- Complete threat modelling, independent penetration testing and compliance sign-off.
