import React from "react";
import { SafeAreaView, View, Text, StyleSheet } from "react-native";

export default function App() {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <Text style={styles.brand}>GLOBAL REMIT</Text>
        <Text style={styles.title}>Money moves with confidence.</Text>
        <Text style={styles.copy}>Send and receive internationally through supported payment corridors.</Text>
        <View style={styles.notice}><Text style={styles.noticeText}>Preview build — transfers are not enabled.</Text></View>
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:"#f5f7fb"},
  container:{flex:1,justifyContent:"center",padding:28},
  brand:{fontSize:13,fontWeight:"800",letterSpacing:2,color:"#087f72"},
  title:{fontSize:38,fontWeight:"800",color:"#152238",marginTop:22},
  copy:{fontSize:17,lineHeight:25,color:"#64748b",marginTop:16},
  notice:{marginTop:28,padding:14,backgroundColor:"#fff3d6",borderRadius:10},
  noticeText:{color:"#75530b",fontWeight:"600"}
});
