# Mobile app starter (Android + iOS)

Create the Expo React Native app:
```bash
npx create-expo-app@latest . --template blank-typescript
npx expo start
```
Then replace the generated `App.tsx` with the starter below. Configure EAS Build after adding the project to your Expo account. Do not put API secrets in the mobile app.
