export default function Home() {
  return (
    <main className="shell">
      <nav className="nav"><strong>GLOBAL REMIT</strong><span>Secure international transfers</span></nav>
      <section className="hero">
        <p className="eyebrow">MONEY MOVES WITH CONFIDENCE</p>
        <h1>International transfers,<br/>made simpler.</h1>
        <p className="sub">A single platform for sending and receiving money across supported corridors.</p>
        <div className="notice">Preview environment — money transfers are not enabled.</div>
      </section>
      <section className="cards">
        <article><h2>Transparent pricing</h2><p>See fees and the exchange rate before confirming a transfer.</p></article>
        <article><h2>Track every transfer</h2><p>Follow status updates and access your transaction history.</p></article>
        <article><h2>Security by design</h2><p>Identity checks, protected sessions and controlled operations.</p></article>
      </section>
      <footer>© {new Date().getFullYear()} Global Remit. Service availability depends on local authorisation.</footer>
    </main>
  );
}
